<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.6.0-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a54f1a2474e44aa4f9b02a98ef8b8ffc',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/fd276009947120329bd8f41c56f24b6f.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'd18ddfb1872f10390762197b98a9f0e5',
      'native_key' => 'd18ddfb1872f10390762197b98a9f0e5',
      'filename' => 'xPDOScriptVehicle/e5eaa236e47c075fbd5b113ce3377178.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'bf8be6dc430db00a49c7de8dcddc8cc7',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/00d6b161fc97fa2e73cf277f84f7bb96.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7be8a1ed4838f7e8bba0d37b563b12b8',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/783bdd433e726e88631a70071fdacb9b.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ca6c674891efd2998dd6452ce8bff088',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/2132f796b2fe72bce6a777856ca75fac.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b298a4c87e28d1a8f768ab5fda56a87',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/febdb677f4fdf1bb9329fa022096af7c.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6fe4fd74f4a6be75afd3c5556d9d307d',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/a8c6f1edce7bb1d5c5a81dc4d3b22e7b.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '990c6f721c331c6eacdaa75a843aabb2',
      'native_key' => 0,
      'filename' => 'shop_config/e35becbf2cb4dd6d5740b5f97971b3b5.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'b43bc7b4fdde3aebfd42afb7892b6d53',
      'native_key' => 0,
      'filename' => 'shop_config/412c6e880dc5e782132ee1a9b4b34bd5.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '99536a098193de583ab0faf1a9096763',
      'native_key' => 0,
      'filename' => 'shop_config/e1b475dbdc60f90289c85326af5d0e69.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'a4e5a83996c0e66b39b304eb152c4383',
      'native_key' => 0,
      'filename' => 'modCategory/6e5e6c19ddb1348b58e84955b12ff150.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02b4a5e7082af8aeca251a23306bc55f',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/999c4cb33ccb9c0fc9b0ebd99cf0e80e.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'addcd53770cd5678a1052c18aa796602',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/f85597d882c41f174c3816797818cd8a.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92648a3ed98977fe8fbfe29be6d894ab',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/bc412b9859dd3417fb50f3e82b84e7e9.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a8020dd6ff1b4892edf3bb11390b76fd',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/2122c789a6f3e3b28914a758564dce2b.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3215d1682d240cd7240c58b60a165fe5',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/c094fa215f176d6c1b9614dac1d60a11.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cea07b7cccf19633502bd53b9b511c4b',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/6c540d76a0c1f202a30777a408077222.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbbeff32e838b3ee101307d3260ec96a',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/a5f7e0141e25447c2ec4171d58b1f794.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '330ff9c1b31d13958b1e6f3ca5edfa25',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/8f0759e5352eab57b41439bae302d118.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1800b9687c24a2a205e2964a81ea245',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/49c6aa41bb40343028145cd0e356a890.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'a08c87d25259b581dd9eb9930410e3bb',
      'native_key' => 'a08c87d25259b581dd9eb9930410e3bb',
      'filename' => 'xPDOScriptVehicle/647114f566c9400aee8ae2641515c894.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);