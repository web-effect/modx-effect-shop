<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.6.3-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5c9e879488dc0cbc1053f58f04197e38',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/2c53a3f601f7b1ef1ed0607b080004c2.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '4637e3aa2a1d723a561f3b422c6bd1e3',
      'native_key' => '4637e3aa2a1d723a561f3b422c6bd1e3',
      'filename' => 'xPDOScriptVehicle/0f439ce4bd303bd540a9e612c13e134f.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd482d24afd91dc7aa50523fbd5f56574',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/70760552afda10c825ef4c5579ae92c4.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e9d8e2f87656e025b63cce6d16c15800',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/9329e82f70e62a3fd94e2976ffe3ba4c.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c3a63181a60ff091c65084fcad5fde5',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/ecbf666d7272cf99e7720237130cb40b.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cfb64a98c1b16bbbc6495204f39be2aa',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/b7dbaa34ed8311e4daeff80ceba595f8.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4ef68af155c674e7bda6f51fe33f3a3b',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/a4a02c94598dadc6f5615c9e0225063d.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'b55b63cee8c80fb5388accc4301062d5',
      'native_key' => 0,
      'filename' => 'shop_config/29f8f6812be69f424e4c26d3a8f2ebe2.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '13732c62949b8489d892b01c973db9f4',
      'native_key' => 0,
      'filename' => 'shop_config/092e327c8defd28bcd13b264dbe0c04f.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '2aa958ef3d775f94c3247c56ab72bd91',
      'native_key' => 0,
      'filename' => 'shop_config/88a08684089c977a2c1a024140ba5b87.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0de972e78e2900f0bdb76244b08019ff',
      'native_key' => 0,
      'filename' => 'modCategory/222da3263cf755b907da82ccf091d7ae.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e1b188dc0e26fc295f725fd77cba6d9',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/5c8922c171cf3a73fd4faebc061c9b70.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e53cc2714a16b5d111f8bdc0f7145a29',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/c2f02c6c2e0ccdbb544734b15cdf605a.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3692593a9c8eb3e3c0669ee39939777',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/0c5a098a1f049cdeaadc476ed9a75a33.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd2d0357aaf36e49a5e77658dddce88c0',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/f7ebb0837932c441f3e2d0575de14805.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd155147b32f0c95d4f6a86ea30acdd09',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/b6cb195fba37f5ded67b1fea8a2e6078.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1cc80c199c6c7e79d65cf4e733b5cfe',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/cb41b330240bc560b66a7bb265b337d6.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6389564e86bfe42a50b699f9d6789850',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/33c8725903f319972d14f2cbe6aae5b3.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dab1cffbf262a07b38bdd4516d8afe0f',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/bed8e07eeefdd611f6d73d75536bb0c9.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1cf1b90adb3fa4a8bf29f125289974aa',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/514a629f12be0a302fd84248c9920ae8.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '9795e2d2aeb035004298800a8d83c29c',
      'native_key' => '9795e2d2aeb035004298800a8d83c29c',
      'filename' => 'xPDOScriptVehicle/3549e118db2a9b25cfe9e9de6ba1e78a.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);