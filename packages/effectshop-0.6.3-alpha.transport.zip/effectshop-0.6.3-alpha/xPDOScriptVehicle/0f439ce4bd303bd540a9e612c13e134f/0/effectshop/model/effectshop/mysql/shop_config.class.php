<?php
require_once (dirname(dirname(__FILE__)) . '/shop_config.class.php');
class shop_config_mysql extends shop_config {}