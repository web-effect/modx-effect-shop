<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.6.9-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4e8c3cddab5e13e065cafa9d8653d704',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/85477cfc2c9b015c49e1422e9099980a.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'ecc9e547a95736a0206561fb4d0fc420',
      'native_key' => 'ecc9e547a95736a0206561fb4d0fc420',
      'filename' => 'xPDOScriptVehicle/87ddd090fa11afa8858831db9b59ddd9.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '00894c56bf493c1900eb942998ffeba1',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/09e0970d95c02cafa455d6d2cd809eb3.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e2a2c977bb77f278614c17f09ab06d18',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/7e804b6123db761781cbea89005d5a3c.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '930535a22de40f093bb3f81b9028670c',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/1b81d3582363dedbd266c9b95d09ecc7.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'befd89c963f92ffa81de64592a758eb8',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/04b433cb6686470c3b380d55af960517.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3fd526ac5a81b95bb47b0f97a404a137',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/41e776151dcd4d3f760b37a3c2d73c60.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '461f7003dc213212b481758445a815e7',
      'native_key' => 0,
      'filename' => 'shop_config/0b74e9afced1b1c3af1ed7a1b9827ba9.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '692ba95872ac2651aef708dd31116098',
      'native_key' => 0,
      'filename' => 'shop_config/7f0488488423bbab34f3582786885efa.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'e487c25026bbe4d4d461736469b1b767',
      'native_key' => 0,
      'filename' => 'shop_config/4cb7fd3e091528ca941dc7f20269d69a.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '87399a7c4b4df3014e2b3eae2c21fcfe',
      'native_key' => 0,
      'filename' => 'modCategory/e854d03691e254dd66d06556426ee557.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec367e923950a81e07f1dfaef21811e8',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/e48f1babc8b3f331b8d5cc8aa99b2a24.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '80680b3a49cb3517523e8a1468635bee',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/a192fb811e472f45bdd761f37cb0c087.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '481d35256bc3e3273823df1f7110f1c3',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/dec82f0bc1baab0a46614e17bd29ae91.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5bb61e99f6ce38956e9910070d2bf71e',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/d737bb755c8dee71a83fbe887be05fd3.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '476013a3d9428d724f2e0133bb54e359',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/854036c96279fc7747b1b2d4214e52b8.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c2f2a829788a04b8d8a046603b68955',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/24cf9c1b34ea95656d559ce8b7ae986e.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '85e7f5cf378c67794fb59c733b5f5452',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/707a9dfed7bc1e0d312a48ca2ddc1ffd.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6174863761510fd835bf6db19435f1ec',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/e4c2cb8e24fb046abada3b3b660f5daa.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f22bc309f4c1cd0b86b17148b8c82e74',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/b713bd6802f2c1a2fd5ec0d6d4f0a877.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '128e50a3ec0ec3075e77db29326ce2de',
      'native_key' => '128e50a3ec0ec3075e77db29326ce2de',
      'filename' => 'xPDOScriptVehicle/cc28e330f85c679d31dd3294b6c35ff9.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);