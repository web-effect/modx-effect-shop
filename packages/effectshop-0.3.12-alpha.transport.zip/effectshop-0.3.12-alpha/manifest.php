<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.3.12-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '4dbb06c7733357acec10359960d95d8d',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/997074ca03fba3c89c731f9335cad247.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'c6268f0952f03de70f070495ca8bcd1c',
      'native_key' => 'c6268f0952f03de70f070495ca8bcd1c',
      'filename' => 'xPDOScriptVehicle/3f939d792526272b624f9981f867c6c6.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'c791969a792b73fab4632750f0814f1d',
      'native_key' => 'Shop',
      'filename' => 'modMenu/cfc3479c63085de7c8e32608857553ae.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'cf5ad4a2a528ac4603b6542f23d4573f',
      'native_key' => 0,
      'filename' => 'shop_config/59bd7c8150a44dce8b954720c30e0233.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'da75eac9b2fb014c65009ff824d0956c',
      'native_key' => 0,
      'filename' => 'shop_config/9b1ecf88bf2861f8de6874645d9c6232.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'efe7321608937386c3f00fae284b37ad',
      'native_key' => 0,
      'filename' => 'shop_config/1ebed0744a1e8efe5cf0a9a83ff1c169.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'dc848fdb14b1f99beb4869af73af204f',
      'native_key' => 0,
      'filename' => 'modCategory/a5ae7dcfb7b2860be1f35c157a4a2ee0.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '06e00bc087fb3305449a4836eae5192e',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/e6ce3fec4b16d6afe4db462133819b13.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bdc70ac65ff4e25f9c207dc51d05adb',
      'native_key' => 'effectshop.product.tmpls',
      'filename' => 'modSystemSetting/983b219b03c1185bc5645c26e1fbdd1b.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd743cad0fe7ea3c59aa20847921601d1',
      'native_key' => 'effectshop.product.get_fields',
      'filename' => 'modSystemSetting/f30a0c662ec6a13caae482ebdf23dcf9.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eafc8d2c20ea76855a16b1c3743346ec',
      'native_key' => 'effectshop.contacts',
      'filename' => 'modSystemSetting/bb38b814caf771f6a81367f003bcfb51.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a2090f30339740cdd936ef60a8322a76',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/323bc1cec9b2fcd9324c412308dfc6b8.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '516c95687d080cb352d2c16c59c26b54',
      'native_key' => '516c95687d080cb352d2c16c59c26b54',
      'filename' => 'xPDOScriptVehicle/4a608848ba8da2230d168f5707446363.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);