<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.6.5-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '9c00232352066c4ed77a3bbc7c2bb767',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/00bc1a9bc24bd8185316460dc3029a70.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'dba9804cf2064757010b9baf7098ddc3',
      'native_key' => 'dba9804cf2064757010b9baf7098ddc3',
      'filename' => 'xPDOScriptVehicle/09cf277b7b9de74587700fc11a5a31a8.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '119451d2300d314a103bb6ef1e2dd306',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/587a85d0783c6edf713ddd9beca2f7eb.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0b20519ae64e133a23d0d6ea77f9529a',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/950549543fec217877de8549ac7cb343.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '183409eb4d8310c4d967c9d3cf3d1fff',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/31b615558d00b0dc671e0055900c2f97.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f4957026d5d247a9314ed2f4c052992a',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/bdb8c344ee9b1056cd961a6b4d6e9cbd.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0ccbeaf9eff98e3fa7c6415f71d64aad',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/d80b3be4a21ce9ea3c59db5031ecf818.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '33a79ffceca78dd95e5c77d1ed6bf17a',
      'native_key' => 0,
      'filename' => 'shop_config/c55c58e1a8250db67af128611c510c03.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '898a53dc2722f124e581b15eba5e8078',
      'native_key' => 0,
      'filename' => 'shop_config/75101b65dc1664186dcfd36b0c4115af.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '4ce9964cc0c00ac5620e86167b0d47dc',
      'native_key' => 0,
      'filename' => 'shop_config/e48bdba8983f552a41e9099af5f52126.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '53c543b13a1aa7b1df7f239561025ea1',
      'native_key' => 0,
      'filename' => 'modCategory/db5ea6b823223e94fb5151628f8f6595.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5abc8bb2ffa8f73a44618a5bbf645376',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/309b1735ed37c8d52cb5d1c214cabd99.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '13871067317c5598efa1316ed9dcc3a3',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/2b86decc692780f86473425bd9c66cd2.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5ce0a0526bcd31f7ea151c8260b203fa',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/be7c53ddd60392c6507b5edfd52a34fd.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4b3aedb907103a33385bf9cb8fd78d8',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/5a0aa4c11ada422f562370fee44c129c.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82b336a0a766989c246cc2b6c351b5b6',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/63d42d4a9e4b8717b6d06eb0b838bfb0.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bb05a97e32144e320de9f985072a66ae',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/c0d8a3fb79e9f7fba27d23ad75a82c75.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f172750a0386bb91ced9dd6273f6c23',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/6a5fadb99e8612ec55154187af1b9abf.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8569c7887d6e311818a05f0038eb0f26',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/d762ba9334074ba54038f519532026b6.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c98949631a83d28ade25cf1103cf0b2d',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/3ce182934dd8c6d2dfee90b1e3efba74.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'ede7ce328d41f86e563b9bc04172e5fe',
      'native_key' => 'ede7ce328d41f86e563b9bc04172e5fe',
      'filename' => 'xPDOScriptVehicle/3ee20d1ecc13e52ba0dfcaa79be514c2.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);