<?php
require_once (dirname(dirname(__FILE__)) . '/shop_order.class.php');
class shop_order_mysql extends shop_order {}