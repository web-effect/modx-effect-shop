<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-1.2.6-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0c31bc64c509753688624feaa1ccceac',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/cc4969c7217b676076a1c454bd7cc44b.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '5e19a301263b8adf3651ae4430605074',
      'native_key' => '5e19a301263b8adf3651ae4430605074',
      'filename' => 'xPDOScriptVehicle/732e861fbb94b4e162e618b2fe4644a9.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6d1b23291162fb534fc234c659250ffd',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/5aae2d4399ce97c203d5352a6e8a5944.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4dc1b69f45ab89a5e42b41982f5500ef',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/504f4706255dd98cb8037c3796670628.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5e90974b6fca245d1a2b5e019a96f168',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/dae17703facee46aacfb382f711ab479.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07a0ddf53fbaf644bd3f3542551f3418',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/154b5674685403c1cd72e8a54569298f.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fa0b136c0407f0a089d81335da5016d3',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/94c2db83d0f046fd56eeeda7ec412bff.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'de79de7e56d15cc62f124f7b49d0b77b',
      'native_key' => 0,
      'filename' => 'shop_config/2f43c7c2911efac7b7d162e6ff799476.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '2476f2e051f99a4f76aedabae1d2efa0',
      'native_key' => 0,
      'filename' => 'shop_config/32f9e88c23cb64b2704f4d7776209fe1.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'a9086f86d4be61605ca46f1b0bf32aa6',
      'native_key' => 0,
      'filename' => 'shop_config/dda678e4665592827ff9ac4f1664377f.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'dab0ae659bf723582df177ab5b07cc79',
      'native_key' => 0,
      'filename' => 'modCategory/c4ed89999618c6762ca104741e841d36.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8abcef1a4aac593694a76eae8dd2f66',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/d8b2fc80a52b7e474469e48b5637e26c.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2c5551a033679fadb4afc0ca64ee7b5',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/7c1913a3c638e736279bb46ebffc95e0.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ee32ed558ce6091b37d89de5f2aa55ed',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/12f5c8fe8e981943594dc6216cb6b81e.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9c8abfd2f359af4d4176d9458857f0a',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/3e2693fadc65155749060f020ef8a7e2.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ff20af3767cffc9d2016d2567b209f9',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/9719d4ea237a92c18a2d759954ffbd61.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e558961f515bc9e6e7846453863f6bb',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/a91fca2c03b3edcd472c49ca7732c26f.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f3d1f19fcdedab2adc17c1cc91c3619',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/195a981936fb3b7675980c8fcd326e11.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82a63ea3c5d63e94aa053d13d72c3b1a',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/d55fbcd22a851675f176b32db3989ccc.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd6ed347d6352c0a1cd3f7befa0a8bb1',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/6a4a008a0fd0a84471af5b19ce0219c0.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ce8de8e650bf0cbb152d31fe271d8c7e',
      'native_key' => 'effectshop.subject_order_admin',
      'filename' => 'modSystemSetting/e2388c23d74a833b63954fed181d4322.vehicle',
      'namespace' => 'effectshop',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '491330bda65515e97a97830d875c992d',
      'native_key' => 'effectshop.subject_order_user',
      'filename' => 'modSystemSetting/413009eb73a6e1837734c0e018f23b01.vehicle',
      'namespace' => 'effectshop',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f19c8fed4158c7beb8f2113954dc0e10',
      'native_key' => 'effectshop.subject_order_status',
      'filename' => 'modSystemSetting/8cf3c4d26b62ceacca4ae5bcc2b7ae86.vehicle',
      'namespace' => 'effectshop',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'd2e0039abb937a69bfa9ff3b13837f37',
      'native_key' => 'd2e0039abb937a69bfa9ff3b13837f37',
      'filename' => 'xPDOScriptVehicle/0bda73abe4ccb8291edcfcb60f827cb2.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);