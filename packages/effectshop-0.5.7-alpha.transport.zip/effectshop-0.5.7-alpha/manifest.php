<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.5.7-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '63da8fb52f26d36149cb0ff09493683f',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/1c59fcdea4a09df09eecbae77ea00937.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '724c8a60e1916c2b24e4374c91a6244a',
      'native_key' => '724c8a60e1916c2b24e4374c91a6244a',
      'filename' => 'xPDOScriptVehicle/fffed87dd21c523b34554c59d16028d4.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '852b17fa846b453840d5346358da4532',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/33dd3632798be651a29b123d3aaa0490.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd376b9e22d60755c89633c9fd80f3fff',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/7b878b597f57041cf6db88ce4bdc1d0a.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edea0210f25a156c84afb07cde34a4c9',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/1fe16047a1da85010a5dc87eec50f3fe.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b77c7eb842f0122d2c40c528b5dce97c',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/d6a22e96b04531c6469ac833718a53b4.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '80f2268fcd59c9582276c4488c3c1cd7',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/d311c0d071d71a039ed1cc4e4b5bb803.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '263bdce0edda96146a5a0ef9a55598db',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/84c6589a8b5a2e296a563fac2c677d43.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3cd8750c6989a0dcce90188f7532fd4e',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/37567e073035471b64730672d26269ce.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c92b47d5b98ba9bcbcce1ecb15ff541',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/47052ac449c56cdcb4b035131b67c2d5.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bc6f64e7dd29049583b12f34e047aa7',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/e6ff6087a70b77bd528697f566ef44e5.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1740feee48927c4f3d7d2b5241321476',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/e992fbe4685b17995e6f8f66633733eb.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb35a97f642e22db991034e6bed0ebfc',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/7f6e74cac33973ffed0b88eb5657ca15.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d5804f22e82de09f4380f797b4ccc3b',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/84ab282b1c14d79f0cc63abfce3a9494.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '62bb7a43e7417a0b872933692bae5d9e',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/4b373296274bdbf3df23f4c531120f01.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a08d3c586d3b82aac0dbe8e6311f1edf',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/2ba865417ed6b800e2f0c0a1dad10bb9.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'a01f9eecc9ee8e966c55ed784e6888bc',
      'native_key' => 0,
      'filename' => 'shop_config/7ebc106859c042c1d17932d350f86421.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'e145ba3e46f250bc9c08f56bf8b89e6a',
      'native_key' => 0,
      'filename' => 'shop_config/f6b5f34d44fc83d04448471c08145603.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '8fee308a64b0e7fc4c51dc011f745c45',
      'native_key' => 0,
      'filename' => 'shop_config/df0b2fdd1281640079ea20121279a2e9.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '092e0199655a8529c7d153d973eeff29',
      'native_key' => 0,
      'filename' => 'modCategory/7995e5f085c38a300f6011d007239b90.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '2e86b3f653f8c381a88f6f6b77b1b633',
      'native_key' => '2e86b3f653f8c381a88f6f6b77b1b633',
      'filename' => 'xPDOScriptVehicle/61b8b0a5cec2dca445eb528297ea9b40.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);