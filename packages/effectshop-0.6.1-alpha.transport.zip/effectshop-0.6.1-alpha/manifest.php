<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.6.1-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'c533710bef79ac75f747fc386c479020',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/b7c484eb54801fdcb6c93016d51e15c3.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'b9d74bddf00f39ebc17d2a68ef2e6af3',
      'native_key' => 'b9d74bddf00f39ebc17d2a68ef2e6af3',
      'filename' => 'xPDOScriptVehicle/82bebd78d269c7114ed7b3502ef1dabe.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ec1b7d27ea7207ce628c3003a2d7667d',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/7385d8ac823c6b62ba8348398029cabb.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f480d2466c5ba715bf1cd5fe3d8ebeb',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/c32f99244f84d7f6d33888593fdadbb1.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3977389e7a3082b069eb2f869642d3b0',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/1a1e98fa6dc35328917b10e096aae948.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9a6a2a1f945a413ace5d79f5245dfcb8',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/0d6e534a68a4749d3a808f679e6c1120.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '73bf786b41b5fc105ca464991c56a715',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/0b87d157d6766a39ba24b8de715f8b66.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '9610a03878e167e168f0a567f7ec5dad',
      'native_key' => 0,
      'filename' => 'shop_config/795772bb3c1d3c8c57f6abc460d44c5a.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '2b54c73f98c17cc71070cd2bb4725494',
      'native_key' => 0,
      'filename' => 'shop_config/387aa3b9e2548beb301a6c653791e1e6.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '679288622591b015fba0e112bdb4de8b',
      'native_key' => 0,
      'filename' => 'shop_config/56809f92e2ffa7a13a474501280632e0.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4a3e37e920557bb2f9d4a0885305346a',
      'native_key' => 0,
      'filename' => 'modCategory/82fada94de024b3b0f2daf07e3b60080.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3a9229cfcd0bf48a8aa4b110b2579e39',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/f985173d8f9099866dd8b132eb6ace65.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '220f492d1a508130feb1eb3fe5c3c0aa',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/2b8157f9c1167034984922f3b9802e45.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27dfa30f0220bc2ae9df4bb321f8f2ba',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/3310e883bbd48fa87c697f40eb18050d.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac87c20cac8718607ee71a177c73b6d4',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/d696e53ffdace9b11d05ff4784cd58fc.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1edf5defb6a916709f1d15ab1208610c',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/d8adf12d9f40a23ad8c79c54c7b42705.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '02cd4f59ee8a0f9761bcee9276ca58f7',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/dd5e3e71b6253fca8c788fe249d1a507.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '140727fdc7f6ee7ec1bfc266f60005e9',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/de3b88410805e276133268d2319a865f.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '871749e93e46d10709f6df100b18ffc1',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/f8c4093cf1b3baf217b2af51b9959c76.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43982be533e855f48974324ef2e08b07',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/d31afd7c7a8d402ceca11eaf47ca87ad.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'bc6da76da73cb75adf975437b1442566',
      'native_key' => 'bc6da76da73cb75adf975437b1442566',
      'filename' => 'xPDOScriptVehicle/b007e8ca1f44241029d7a25db12cb2d0.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);