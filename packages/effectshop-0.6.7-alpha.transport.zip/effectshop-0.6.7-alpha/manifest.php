<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.6.7-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'cf4f13668372cff0534168677e2801d6',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/618ee77b47ae36705ca448104255e22a.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'c722648dea2aa3bd6cdb57030bc4678d',
      'native_key' => 'c722648dea2aa3bd6cdb57030bc4678d',
      'filename' => 'xPDOScriptVehicle/a0d18cfd1556da814eb51f0e928b0b90.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '58af4d4e0b77a486fc436d025598e188',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/31a3affc494ad7f305ffc7279b905f93.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c1917acb12b6304c75a329d24b7b233b',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/604b008dc4a3ed5d5eb97adacc6f0c14.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '57cb5c47d8dbc7e8ea673c208c0e16e7',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/98a3de61c2b5186c160211b8b7c69fc6.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '62d84fffbefbd08a8482be7bee570ba1',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/f41d1086ab994857f84df5861de67ef3.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fc32193e17f89b29f30aaa09af0bb3d5',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/6292337f505fd698288bf8c9dcd9a64e.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '1dc7ebdaf80f0296b9a90853e4b1c9ca',
      'native_key' => 0,
      'filename' => 'shop_config/a4243f6d1306f2e24dc98cf4f287b736.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '9b3295f5e5b8fc4e889248366dc973a6',
      'native_key' => 0,
      'filename' => 'shop_config/b2f42d48ab8509e7e439233aeded21f3.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '400266219edbba262f47b102a14221ea',
      'native_key' => 0,
      'filename' => 'shop_config/fb24589b9677b60960f0b3355790540c.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '63eaf5e10b4045cb4b7f947692945990',
      'native_key' => 0,
      'filename' => 'modCategory/237d8909451104b1ede64a9b4f1fb8ff.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a68317d77a09df181daa93b4c749d1ca',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/309355a9d497bec5c512210518b4b04c.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9ea8978fd08663ecd89a64353b4741df',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/9433039d07034bebcee390b80d8f8e4d.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65e88cca88598c764dba8f1b3651cb98',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/d0e4ee488564ee531a15353c132a4652.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7bd2bfcba5941f40fca21f91b19682d5',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/257d244183acf36e8bacb4d452d76b39.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '732b86526abc4715e3cae549901d401d',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/cb5d7a6edb95cd09e1d18c87b82ed655.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec2b20577fe1c72b38d04e38fea72b4f',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/d34b0bad5127863d717dfa325b9b8276.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd87065e3849807bc87aaf769476a3e82',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/9cebb28278a32229cb1348eaab663d3d.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0d905934b453181652457eabecaafa12',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/71e960a5d884194585ea32c5bdeb52a3.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c5f01ff0bdc860b6bc4562d66bdea21',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/8f06d026cb59ef3e14b3af6cfc986582.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '5f24695e0495fe280ad097720c8dc37a',
      'native_key' => '5f24695e0495fe280ad097720c8dc37a',
      'filename' => 'xPDOScriptVehicle/8176affad866abf5f4a8cff649890eae.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);