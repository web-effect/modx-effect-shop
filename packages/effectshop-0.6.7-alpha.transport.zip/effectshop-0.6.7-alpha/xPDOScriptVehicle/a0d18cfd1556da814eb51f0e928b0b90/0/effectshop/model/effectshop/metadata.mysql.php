<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'shop_order',
    1 => 'shop_config',
  ),
);