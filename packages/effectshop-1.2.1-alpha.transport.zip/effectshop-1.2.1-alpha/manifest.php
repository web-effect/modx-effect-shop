<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-1.2.1-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'da71c6d8d8ed15b8ba93a090f3aed4d7',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/c73d2df8c90684cfec4b7412b510778f.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '66ba8a2d38c4b976caba0e2f4b4067e2',
      'native_key' => '66ba8a2d38c4b976caba0e2f4b4067e2',
      'filename' => 'xPDOScriptVehicle/c0dc2562aa65ace30d730644a378427b.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '4c7548ef8c978859451cb93ad2499add',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/56da0762602ff8fda19c0a474c00f753.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '39974df4d96ae0a87c09bcb53f73375d',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/ee6914a232f550845b0c78d35397c0db.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70a2b7022f225eff57a5a00e34503111',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/d629d485f8bbb1896b942eae0835951e.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3775cfb66cf7540f1509cd179f77d9b7',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/cb7af02c75488fd41f87d61226054c10.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '561c8011dabbaaae0c700df842f5af17',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/b62057f4cd6fa380293cd31dcec7c441.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '926e996e147191eaa1bebacef8ff3173',
      'native_key' => 0,
      'filename' => 'shop_config/6e711db10107fa1b880322bc5bd2720f.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'cefaa2bee2c6e03eb53ec345d9f15803',
      'native_key' => 0,
      'filename' => 'shop_config/743771690da7bda802c38fa8715cb90d.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '521dfafca99c3795464ad83b3ea11fc1',
      'native_key' => 0,
      'filename' => 'shop_config/43271eb60bc434de6d5a0780a553b1a4.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'e1c268cd120d2fb5c11f5e40ac2588f8',
      'native_key' => 0,
      'filename' => 'modCategory/62cc7b377f4378400ef9255ac141f724.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dad2602cf4575b1c96f72e16f4fe6976',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/8c8a3a8d7cd3832d7a9be2a17efe8695.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a2d8361b87f15f88db1308f6e4ca2b0',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/59b441097e7c53529a044b342ca25eba.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a23e9d3a1bf6c34fb324a11a3475b021',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/cbb9856278f0ff34b6b1610fd12b3c96.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0b8e3e6fcc3fafd2ef7f46706d0f47d8',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/7fcbe554498cf14523fe0f41b0d9b0e2.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ccc0811d74b22d2301c587c275f23a5',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/54b9889e51d49f8383c5042059cd7eaf.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b352227de4b29d6203c3118e7f9925cf',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/45e4dcf05b97adfe7de6e2c0d591e277.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92af358e18bcd1ea3c82e77dd1529952',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/0050cb969d731c0fa0cedc35076bc614.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33bcc0a6ed152adcee4347dacd63598d',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/8b18f5d75a649e6de60ef857ac0bf370.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64000c9651ef08abcf93e616179c20b2',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/d40cc4c6bb1a77d0274b617defd1572d.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '9abd09503d19f6a1ae0094a4bbd85a5b',
      'native_key' => '9abd09503d19f6a1ae0094a4bbd85a5b',
      'filename' => 'xPDOScriptVehicle/bc590e5ac3a0822736607ba39e241e24.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);