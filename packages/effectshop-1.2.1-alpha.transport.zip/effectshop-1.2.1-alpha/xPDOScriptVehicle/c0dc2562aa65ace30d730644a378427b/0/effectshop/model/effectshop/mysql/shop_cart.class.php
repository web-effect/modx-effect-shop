<?php
require_once (dirname(dirname(__FILE__)) . '/shop_cart.class.php');
class shop_cart_mysql extends shop_cart {}