<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-1.1.1-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'e7d0316f156a7c9d7e0d6880838ff685',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/7c5e51c9381b122e4b72350dcecdfe44.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '996a93c078ffee81bec99dabc6d4656f',
      'native_key' => '996a93c078ffee81bec99dabc6d4656f',
      'filename' => 'xPDOScriptVehicle/5d8c86d8c07704191cde6095b63093cb.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd4b1a56dc240b569edf3a9d6b06288ee',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/88cd487b6828c5e4b571a997f12df47f.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd326bd9e1c02147c16e33555c77e5cc8',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/98b2b42e189fbdf07278226a76e2557d.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2334172800a1c044c1f08ba504d2d519',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/3082117a249468a8e9cc5c0fe806b655.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07ffbb0893e340e74dda766443e7b7ae',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/be49ba6ca492f70c51f9460d6cb31588.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40e58c0fe506fb8acf427026ba9b8e3f',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/1759b8b73e83e631b319ce9fd67c7463.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'fb916deffebb1a5111a1913cdeaf486b',
      'native_key' => 0,
      'filename' => 'shop_config/5755d443ef75d0ca78a76a9bc4ce8328.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '5882ffff1e21646c48c422e3e63b1d71',
      'native_key' => 0,
      'filename' => 'shop_config/3e1e57fabe8b908760e58dcdaab2d2dd.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'e1f3051d4e5be16c76757d430da4040b',
      'native_key' => 0,
      'filename' => 'shop_config/aca769aa3cc927cdd1d971386100b825.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f7627a25876703c80e4eddaef3079e56',
      'native_key' => 0,
      'filename' => 'modCategory/0d8a261a007189c2cb8c3ca0ea399c8c.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6b4312c40fc57ea60af1ef42142b1a7',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/d51a8dfea0093f2854b8c7cd641159ac.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd375f674e7e248c220da04db7f1f96b5',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/2f5aed816928bbfd250802359671d9b7.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35a72f51f7f92ddad5c1859052852dc7',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/18a9e11978dffa2246152530249400ad.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '192ca4e4aea74d6aab4f2d31c5fea325',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/09be81bec5a6e34c77bf781752da554b.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2b66a61852658391fe079061bd60f7df',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/17b3be06e444617d0c36c87429d64099.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10d174660128611338b0f2015323618b',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/f7c4f1e202a78c1d6a01abaaa9bd7fdb.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e516e28e26dcb366d07216c39e05ad1',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/098f2f86f8fc79f68c948fa0bb2b05c6.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c41fca8dd756e95ba6d6f87f8e8cebe4',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/958ba8387c928618facea05f5c94b553.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '092d69a30922788851bb0a072181155e',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/e2b0537770faaf50dfd1c42ce8bcdb5f.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'f471c3403537ff1d95113032d7f881c3',
      'native_key' => 'f471c3403537ff1d95113032d7f881c3',
      'filename' => 'xPDOScriptVehicle/4499b67158b170cef36a914a4378b2d2.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);