<?php
class shop_cart extends xPDOSimpleObject {}