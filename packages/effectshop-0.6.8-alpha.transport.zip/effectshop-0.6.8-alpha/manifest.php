<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.6.8-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'ac36fed91f5d1a8f9f50caddfd9cdc9d',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/5b86a2711ecb63a88d74581e35b7a4d1.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '5bde8e739e442a357e9fb486dd8b8827',
      'native_key' => '5bde8e739e442a357e9fb486dd8b8827',
      'filename' => 'xPDOScriptVehicle/1cd88f1b02de235010fa17be3eaa0ab6.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'b4f6f19c001bc489717b4d80cc00496d',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/8ce8453f5f139bb7f9db36a5c93f18a1.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '66d74fdb2ce6ea439afb8e5f1cecf18e',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/2ee1d616db6c91c0d44e7908ff7eed9d.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '614fe4d15d731c2d7a66ae085f821a4c',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/771bd75cde803fa1e73430a165c181c4.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05fda7a0f0a9115e02c86d0bf8ab5210',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/06279dc70bda068c745b6a3e404b94ac.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'af04135b519fa1e691ca56f80a68ad39',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/d2eb7b17119082106e97b0f5350e7971.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '04c7378fd8200a2e9fd655a2262c937c',
      'native_key' => 0,
      'filename' => 'shop_config/c924a90574795357a107f8464b1f57f3.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '86e9d4789696b9e5e08b10b7bc90ae12',
      'native_key' => 0,
      'filename' => 'shop_config/74df26f3d981a1c055e83637e750a766.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '3da16f91e764bcdbfef7297c0c8f45f1',
      'native_key' => 0,
      'filename' => 'shop_config/44be729bae17e2a7f4efa37c2d0ba41e.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '2a181f3ab857d4c99d1b886c426192fa',
      'native_key' => 0,
      'filename' => 'modCategory/10239ed21a81b985983ad859c8ddaeb5.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c91b6d44102616a8ccbd63488ea47c75',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/322ff970c7428184a90b7b58f3263c1d.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '775dc5fde91036387df882c32c477318',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/261cdd799d872dcf02d2d19f77e99a15.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a219bcfb9b45e6d3af853d02e7b8b458',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/99732d03c9cc54bf8abc07f2a3d456c6.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '65d76907c8711b0ffc2a816b9d3146ba',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/6a57e77f81f3e97eace924098b2c3d99.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0d6faac1e7fc2147c3e6de4623fb546',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/aed0bd0b71a2571ef2476e5eba02d122.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43ebe6d5e18781e30542f25bcaf46fab',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/8f4ea631a464cb925262d0d2c35e3872.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59aa625d122cc3a01dad2d2efac51a4d',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/3be6e69e83cfdcdedd73c13d702c611b.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '408c0770efd3a3a223149ffc56ef7832',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/f18ea7af68982a56d79c44eeac64a7e2.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c93c95c9aeeb3b4a738497c51d782baa',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/8dc8efbcc81bedc7d336785809ffc16b.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '6d2540b15e3b1aa98f658c03ab7925cc',
      'native_key' => '6d2540b15e3b1aa98f658c03ab7925cc',
      'filename' => 'xPDOScriptVehicle/b99f50c4fe2ee1074073fe0f16ce9b2d.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);