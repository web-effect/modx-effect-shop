<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-1.2.0-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8c9f8db848a14632e8eb5711e9119fbf',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/8e2158fa67b3cca9fefde58d4ba1849f.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'f4bb1fbcdc8df1960ee4a0d659d52f64',
      'native_key' => 'f4bb1fbcdc8df1960ee4a0d659d52f64',
      'filename' => 'xPDOScriptVehicle/7a66e6ce33b0a5ea7a10c25e92c7abf3.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'cd525afa3e3ca98ed3d55dc9e7b81c48',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/d8dce6f3b8aafbdcf2b341dd87899ebe.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fcf385243919d81d5dd3470a4537f89d',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/8549958e49a2a9630aca308530726dda.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '38e2a70f279a2aec47529c22971ac47b',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/66c0ed0805533f695079397f4631a7d1.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63ffcb1ef0e3f83a71d5c15223ffabdf',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/96af456286dc2f8f901c1c01d9e59b04.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1696f78d685c8cfd3c8e685b5610e508',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/667c7cf82d4d86e6cc906ce339815097.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'f72666ab6494fa50e956e63497ea9a4d',
      'native_key' => 0,
      'filename' => 'shop_config/3e607f1f98514a6760c835fb74033c07.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'ed2473db7868dcb448025258642cf58b',
      'native_key' => 0,
      'filename' => 'shop_config/d52f6676a08e2966a6270517431ed02f.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '0fde094c37417edb25065c50f1fc0801',
      'native_key' => 0,
      'filename' => 'shop_config/1b4729c4e8caeec5d7eab7c83522b445.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1d89aca3f3a4ab1f7852fdb1da0a8005',
      'native_key' => 0,
      'filename' => 'modCategory/1948a6a44f8e94968697c5c824265769.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51b930df64db1638080e66756058afeb',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/6926359a1a4999849baf2409033d8644.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7c3eecdeaafd99424c10590fa40bc7f6',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/c641c21cd90103bdf373abda207a93e7.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1373d4a3e9d931c8b875e397ca8fa3b0',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/23ca8ebc65e48476977e75df4922c52e.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ff335cbf8209387128020ffd12d109a3',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/d60f99408d05bb3fafca71677e625b75.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8eb9a66b8a1ed7b948cf6cb49bfd8c9b',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/0040d2ebfd8db423cc96bf7635bd296f.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67643add224fa3f586178a73d39c8e23',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/d252bb646d2db893767064ed04b81910.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '475135614b7ff89e6fed465f66a07532',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/baa809a9fb2e73c812d2453d76c7dfb9.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e9bc2e1b9e38eea419504848ada2654f',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/8a0212f66a5c9fd4d8123db3b7b7a014.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f90efced238fe0de782507c895580633',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/a9f0ffaa0fd721fa4fa828729742ed4b.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '3cfbf68c30dde8eee48b0338cbfb2d7f',
      'native_key' => '3cfbf68c30dde8eee48b0338cbfb2d7f',
      'filename' => 'xPDOScriptVehicle/a225855cd1fabf683f61012b081fd871.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);