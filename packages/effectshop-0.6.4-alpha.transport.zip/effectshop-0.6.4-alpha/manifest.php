<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.6.4-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'a3030b68b549ec972982634d513e30ea',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/18ded44465f139e168026d7af4e81c83.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '6a7c7f0c6b6b255730f8f32741a84bdd',
      'native_key' => '6a7c7f0c6b6b255730f8f32741a84bdd',
      'filename' => 'xPDOScriptVehicle/c0f894c8b4f24660c89e6a9cfdc653dd.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'dc280d34ef836e1446108eb1b1e874f3',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/d6929a51f2bfe8939b738ebe4e413cd3.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '28e018553bd038fb5e397e1cf9bb0e46',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/253db7cbae5285c0921c11e84586b8df.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd8b4258dd2adc1ff148731db218f9089',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/a8024b021abfd971bde45a42a3c0e11d.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3cd815e81a9f07ece743bb682d4f2ebd',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/8d20d0884efdbedfb033f49aad90bc09.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '12acd44e3963f58ae0e4af9eaab72b1e',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/146617499fa264810fea3ffe65b8d5c5.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '0d8687bdfd590a493092e66ba7f3def9',
      'native_key' => 0,
      'filename' => 'shop_config/d7b5c9c95091557030a716428a4cf988.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '4be16c1043f3ee15109c833da74d2d97',
      'native_key' => 0,
      'filename' => 'shop_config/0ff506f6a047f8c425e4754a21f6cfb6.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '4417374b6ae137092d1997ee96fbffca',
      'native_key' => 0,
      'filename' => 'shop_config/368c640f5882dfb44ddfea64b5db37e6.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '69fad59dd8294d27892c99c5aac71a13',
      'native_key' => 0,
      'filename' => 'modCategory/32bc56002dfd1dd2e6991e70f7393c4d.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2181de8b1b2245889371d9266646d6ce',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/a5df461f2fe6331ec5c28b5741a38e90.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bd833e4c524d20e71712135750ad5049',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/13c72c4b58762a511287085ac77dda90.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd27de717b85cb4ef30f65e99998e407e',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/7a43c45cb45c411ee4d7cba4a0cee6bb.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a6b4a617c6fea796323a09a6ef89bc00',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/438e1af7fc44deb9487b22c4a23961cc.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '95b5c7af3e14e06a5e35cf2365a33f3a',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/17f18008e653ee191a356f15857589fd.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '227d969f916a85b4d38d48287be8e33b',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/ccf8785e9186e5c03f7a1a2576d721a2.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2f4cd8994bde0ced7e2e67dcf2383fcc',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/1c21bebeb6958cbc425e4f37bc69faa0.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9577e0c6b725adf15f8d2eec3299b83',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/111ebddcedf26e6e344c36019a2df936.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '557a74bdc4c87766818b43a6a73f787a',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/f3c260207774dcdbc4f3e1dae11c8c2c.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'c98cde34f73f6d98e53bc6472c2765e7',
      'native_key' => 'c98cde34f73f6d98e53bc6472c2765e7',
      'filename' => 'xPDOScriptVehicle/3d033d00de8c23ee86a0433b8b84361d.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);