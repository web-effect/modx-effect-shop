<?php
class shop_config extends xPDOSimpleObject {}