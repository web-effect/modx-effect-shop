<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-1.2.7-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '0473578cfa869c7fcd2fe1fda5b91b67',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/08b413bf93b68f09729f8cbb9901f791.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '55ed39a173509c5b19cacd70e5ca92c7',
      'native_key' => '55ed39a173509c5b19cacd70e5ca92c7',
      'filename' => 'xPDOScriptVehicle/13440725097690a7a31d0d3e19b70b0c.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e9d726a2157886be648b42cb072e4899',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/c660a24f3d8f8a54431e98b5d1e10be2.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07a294bb963dea94cb0b735c3aac6ab5',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/64701ccf672edf5bde43a963c863b046.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f14820a38586c3a4c31d31996d1542de',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/a972bcc4259bb145a5ac0fd24a6f6c1f.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a19514df682da14fd8e005cab7073d3f',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/6b63afb40e81a10b51115bb806af1ea5.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed2977b3f7ac098c5010d4457516b511',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/cab043bb7959c799585466a5fcdd9c18.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '39114fc8503f14e89d4189fe421ae4d8',
      'native_key' => 0,
      'filename' => 'shop_config/499fcb1a9a1b891f60b30913f37bf1a7.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '22ccdc02cb18a43ccc5f307c525fd55d',
      'native_key' => 0,
      'filename' => 'shop_config/de7054fcc3556870d8181ee18a989e4e.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '5ddfe6f75fdab5b44e3ec652b0e16208',
      'native_key' => 0,
      'filename' => 'shop_config/91401546377246ba192fc3109d44550e.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'beeecb4e730a6ed30b4a968df2f53cc4',
      'native_key' => 0,
      'filename' => 'modCategory/b787aa847070c9c9589760d679644af9.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98535abbf4492c944bd6669ca4ee48bf',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/cf8d63700ed415d6c68d1d10fa22d559.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9eccdce66ed4440b442679100befdcc4',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/753cc621679abe68d937114435e58736.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9c0bb5ca1069f8a8d4a57077dda23e9a',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/c66aac51b46610d78059c70ffcc548f9.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b2b7d8e77fd82f931184982efa83417a',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/cd0f8356b7065239e2d11c5e1035889c.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b5503b8e4ccba81c484bf9a87fc64ff3',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/e18fff7b2b30b55cfd38b62e629cc9c1.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '334ba2ca3ab77d4b518374e8a8f5342f',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/d5eedb2f1d2691fccf9cd1a8d1a37bec.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b094eb922876202870ae914e1c1b6dc',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/c579b7e5a88098c15d7fb2e50cb219e8.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b521add3d1d01611103f239fe67d189b',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/4989d52626509544a3a49cb4df77c3d9.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebfb635ace47380b8a0f5f066138a40f',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/e671e3060f6c0d6c11986c8bca7e3049.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a7c23befd22aee011a2e0049eb7c3c6',
      'native_key' => 'effectshop.subject_order_admin',
      'filename' => 'modSystemSetting/bf1490ce64665fc7a4394ad792dcaeeb.vehicle',
      'namespace' => 'effectshop',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0f60293468b4254699686a88350271e5',
      'native_key' => 'effectshop.subject_order_user',
      'filename' => 'modSystemSetting/cb6226bd26bab66ecf82221e571a7a0b.vehicle',
      'namespace' => 'effectshop',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca6659f2e5adbf62fb5271be242091fc',
      'native_key' => 'effectshop.subject_order_status',
      'filename' => 'modSystemSetting/4654ad7a868c383304cf13f67c40dd53.vehicle',
      'namespace' => 'effectshop',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'b00fe059a4c2633f735183cde8e25da0',
      'native_key' => 'b00fe059a4c2633f735183cde8e25da0',
      'filename' => 'xPDOScriptVehicle/9520a68a031c3654b2adbae374390150.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);