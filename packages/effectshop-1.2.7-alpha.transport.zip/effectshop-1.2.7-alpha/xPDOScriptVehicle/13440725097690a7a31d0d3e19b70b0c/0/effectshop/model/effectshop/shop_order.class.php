<?php
class shop_order extends xPDOSimpleObject {}