<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.3.13-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '65d69c284f762dff7c3527f7d522f8db',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/abeff589dc14277f10a58c4652aa66e2.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '8ad586a7f46bd33cf956097e456daccf',
      'native_key' => '8ad586a7f46bd33cf956097e456daccf',
      'filename' => 'xPDOScriptVehicle/01bd4a44680db594fef1323a22e9a541.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'd88112339b2c10e83f3402bc36589c15',
      'native_key' => 'Shop',
      'filename' => 'modMenu/f1211342bc324441b88aef1c9368157b.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a678590e3fcd1caf4eef0178637f637',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/932ea02485d8acc2d11c597264576566.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b16c509c60afd9090b74f6381aa3a32',
      'native_key' => 'effectshop.product.tmpls',
      'filename' => 'modSystemSetting/2b793c593a0f114af6b8559fe0b5395f.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d7e9df758d478cf63f8fb7620cba73d',
      'native_key' => 'effectshop.product.get_fields',
      'filename' => 'modSystemSetting/c83d92e19c749d2439248175fac3427c.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '872c0c948503765fa14bd8a0a11ed05e',
      'native_key' => 'effectshop.contacts',
      'filename' => 'modSystemSetting/374dd574387509780b86738ef047ce02.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce56309c24d4f084b0435b1d7eab1d57',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/e24c3ebd2f0178ec574f6a04acaa47f7.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'a4a087568bb016e2c8499b227575a262',
      'native_key' => 0,
      'filename' => 'shop_config/00f6c1440fc3b07e3d84a34f2a7bd574.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'b2a8d6f45abdf098b9836c163a0c188d',
      'native_key' => 0,
      'filename' => 'shop_config/08562e03d6fe8962f479c535ccf03c77.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'bdd056e8b1bc74c679a7035d7ae8e076',
      'native_key' => 0,
      'filename' => 'shop_config/8db2a6842f6c5c7d01c3814de4fc787a.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '56873e38caef984741751a1054ba31c9',
      'native_key' => 0,
      'filename' => 'modCategory/675f5fa4d34fbd240b90f8df2a62df50.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '6387300623573642fdc1a22fa3b79f3d',
      'native_key' => '6387300623573642fdc1a22fa3b79f3d',
      'filename' => 'xPDOScriptVehicle/0d22837e1491cead2311f2f95452f697.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);