<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.5.2-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '67b6761c498dcb29a216cd1253e13ac6',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/c9e66afec5992b5cc7aae9448072e6b7.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '04f5f0181a0e0069c4aa0ce66b35cdc1',
      'native_key' => '04f5f0181a0e0069c4aa0ce66b35cdc1',
      'filename' => 'xPDOScriptVehicle/bb425b6cc14fc56a1ad2fd0b76d21ec0.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '38c458b24ad0e120e6f020e972e761b4',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/aeda46af47695bd3906860702d823c61.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '97f7f451cccfddfc99c12e1f1c413af9',
      'native_key' => 0,
      'filename' => 'shop_config/b2c3cbb49cb46e0a9274b42d176e2927.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '9b806037e5347d7a30c43332090e619e',
      'native_key' => 0,
      'filename' => 'shop_config/7cafb928d707f97c48d5d85ac8f2cc5c.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '2baecadd5805466d734108d408023939',
      'native_key' => 0,
      'filename' => 'shop_config/a0dca88e0fc78ba2438b89ea66650a15.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '50041d4d1f3e54b1d7067e987f9867a7',
      'native_key' => 0,
      'filename' => 'modCategory/4a271fef9a9c5d50f5cb5fc7d7053afa.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bc4ed79e2ea319f6997755f92a3ab6e',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/58f1b99e924787969f0a4665891308dc.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7ffab3cbcf1e6e0f20e8db7ad90e5e07',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/9f04813cb45f62cea07fe14597a432af.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b03b050d7a397693864a2daa6914f790',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/a9b3c47bc0454f487a4c3539488433e8.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '391098738f97e836a37fdacbc0f6f5a0',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/bb0580048a27368a813db8940d2cf324.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4da7974d0c968b137e4baa24b7f69336',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/2ed6699ae9f2cd4375ede5e009bc70c5.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ec8d79b21c988ad0d2402533af2e0cd3',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/e26646dbc8da6df8e5ba6a05d042f5e5.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40827c6c2ae1bebfb8e4baaa6b56c036',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/5afce4c0683f35bce43d71a5ccbbf818.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50e1e5abdc0f0a522022352c82f38805',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/aec03593f5c3b18495f2be6b7643ce05.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0221536a8b06da22c53653ef46bd2e52',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/a2c1236d6a4ac49524207c94814a77ae.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e4aba90f61b11d71ebf6989de4034abf',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/1e50b9acf45827042841bef25fa8eb13.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '51138ad28598c4ff887abf918d312a49',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/62829bb29aa19dec56c7723695c1ac5a.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '279b3139dfe5898e1393ed65d9c6e524',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/72615de415bba9cdf7184ed6479b75a7.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '3e7e29762b7dfde72334a5281293fd2b',
      'native_key' => '3e7e29762b7dfde72334a5281293fd2b',
      'filename' => 'xPDOScriptVehicle/ba6dc154aec2a13c2836e305ddb32406.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);