<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.3.20-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '8480279dd8e3268990b310e63e708a2f',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/12a105a8982efa5fbe2dc398a2042fc3.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'de9fe21aa2c9236e0c3c20af09abef53',
      'native_key' => 'de9fe21aa2c9236e0c3c20af09abef53',
      'filename' => 'xPDOScriptVehicle/7d17f4aff4bddbd56f3d61145f23f2f5.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'ab5628be5a828ee2d1936427c522ee99',
      'native_key' => 'Заказы (Shop)',
      'filename' => 'modMenu/18fc259e85119b80d4ec3439074cfb14.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd0734e73e4a77ef7a8cfd6977315ca35',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/7a2feeed84eeb1b75cab5df732808c03.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd62b92e8a1fac7dd3743164ade7a6e0a',
      'native_key' => 'effectshop.shk',
      'filename' => 'modSystemSetting/3834cc84ad9a2d2c8fb68b2eddae2e91.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '33689f49bca35cf81fc821f05e34fefa',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/1215d09c52e4bd8172adc151e634153d.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ba17b2b80cca833e7947d68afbd58dbf',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/699219f3f3f4d8ffb457119130813e14.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9368372ff91d4ff23ac6bb905c9a9f20',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/82611a4085c12ad8be42cdbc22944bc9.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd25a7d477965af991d7aebec6a1b2dbb',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/b57ba6f044e9e91372e912bfcc039c16.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7b77af2d785a5afb362e7e36f2999b49',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/7b8e26144051ae4b33eacfb2deb44439.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '846cd7686eab76f9be69420c8a4e2e93',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/fad64406fb0743d5d0e878662dbf3ad5.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '337e7ee7ffb49a76e00d5053b2c6ade5',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/ed28bea5b8e860ed12d7444a568719a7.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c539d5d1625e5bb8f0bbad862eddf8e9',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/22406cab73ed831a746389090513582c.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a3ec1b906081f3c1b8f9684075fb9b6d',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/7cc8bc380988de3148c5e22807a35325.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '60b6ab51c1c5506021fae8f151d12332',
      'native_key' => 0,
      'filename' => 'shop_config/d7fa199a537c079e0b349353d460f0d5.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '3ed1c7053f2fbbef6ac60f1a5b4048fa',
      'native_key' => 0,
      'filename' => 'shop_config/a85aa414bfeb5bea1a20fe0d6df78ab0.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '34355c01bb32671e23285012b0fdcf13',
      'native_key' => 0,
      'filename' => 'shop_config/3977e42fe7ab0ac8ecc5c09adf23a946.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '72643e7afa2934c9064119513d47a72d',
      'native_key' => 0,
      'filename' => 'modCategory/3c8796df81c072089b36549ab5791c23.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'c6f143de12cb3463e253c8a607d229e6',
      'native_key' => 'c6f143de12cb3463e253c8a607d229e6',
      'filename' => 'xPDOScriptVehicle/be419ffcf111b2136e090e9bd77790e4.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);