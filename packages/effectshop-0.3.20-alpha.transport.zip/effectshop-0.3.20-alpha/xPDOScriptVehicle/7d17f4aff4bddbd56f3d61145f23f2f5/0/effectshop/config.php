<?php
return [
	//Поля в форме заказа, в режиме shk не нужно
	'contact_fields' => [
		'fullname' => 'Ф.И.О.',
		'email' => 'Email',
		'phone' => 'Телефон',
		'address' => 'Адрес',
		'comment' => 'Комментарий',
	],
];