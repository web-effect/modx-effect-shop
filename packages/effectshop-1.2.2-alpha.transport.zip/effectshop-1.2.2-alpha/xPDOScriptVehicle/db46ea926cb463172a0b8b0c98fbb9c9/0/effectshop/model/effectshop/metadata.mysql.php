<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'shop_order',
    1 => 'shop_config',
    2 => 'shop_cart',
  ),
);