<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-1.2.2-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f965158f1064ee3dae233ab03368dd6b',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/cac09991b7530a4ac38aed292f4dd101.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '5a1d56f0a3827ebf7b30bebb54643c87',
      'native_key' => '5a1d56f0a3827ebf7b30bebb54643c87',
      'filename' => 'xPDOScriptVehicle/db46ea926cb463172a0b8b0c98fbb9c9.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '35f29bb8de3c35d12b66ef2bf0632f1d',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/131e6961849408096e0ecd4d1bc92709.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'add245359ed64c6dd1c9ab53c628ae6d',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/106e90ad321c515863b9143b4317e2bf.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7fa8e376003846e1917a56dfb1a8dd51',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/ece6a1bafd53a3495c778fc2980eacea.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1862b7b4cda6eddc7dcf0b6c0aefcee7',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/91b645eff0f238da80250dfc90080d45.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bfbfea911bee6404e79ab85febf5b53a',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/b38cd3f83161f30a3a970c2ecfe1870e.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '0fe2b5b9f4cc7871eaf8590f5652f549',
      'native_key' => 0,
      'filename' => 'shop_config/cf1172320d023bc07b13763d98e2330a.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'a3a89ff1138f36fa6f18ad54b4a31b62',
      'native_key' => 0,
      'filename' => 'shop_config/1c8efd490e4ea050e2c27a57ad467f21.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'a336d9ad3497cd8175d148148fbfcd10',
      'native_key' => 0,
      'filename' => 'shop_config/3b98abad37683b25310f365cfe22c83d.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '85046a0bec5cc813637f77bc470a09ef',
      'native_key' => 0,
      'filename' => 'modCategory/ac01b06893a2bd0c88bd185581807600.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e8b6d2c7fd93c8510a2160bf1bd4973',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/ba9aea01ef4a35621e85cbe6d5ada141.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b94907aa4d7859227482553a3bd4aba0',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/d205a0373e982ac50a548117b103d96a.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dc684226cedf56a98135e2ae80dde4cd',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/941a47b62554b2420a26f160f0e0e12b.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7df5e99c81208186202643a01a2c8e5c',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/2f13ff899a794d88e8a3baf81431f45b.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35f9f26d82686afed4a8d60a3d7ba5bc',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/231a73eec7b8cde92bd405eb7305c474.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '848ad85ae43e1ac0a8def5413d549200',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/47c570c3cb0e2e8c348240c27b484d4d.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '266382ddf3c9cb669b1393a573a5c2b9',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/39045b9b478ca7b93a70acc08279d98e.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4008f791317fae322c52e046408f35c7',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/c53c3bada23bcd5e98a4b52f6ec19aee.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '085c7acc9582310b5fe8283ca50f67d2',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/6d81ee29468cf5a4dc5a0cf773320025.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ac85f35e37cf23dbe41644b8453a4079',
      'native_key' => 'effectshop.subject_order_admin',
      'filename' => 'modSystemSetting/328c5bf4bb1c852657fd758ac6e438ed.vehicle',
      'namespace' => 'effectshop',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5663d5557156d5fc9ed6b415c18cc35c',
      'native_key' => 'effectshop.subject_order_user',
      'filename' => 'modSystemSetting/30ab14527f5393bda34eff376ddd13a1.vehicle',
      'namespace' => 'effectshop',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6674f8d8f4e10aa1026a82d4295cdfac',
      'native_key' => 'effectshop.subject_order_status',
      'filename' => 'modSystemSetting/0e6690081b3f9627d01f0ba5a1d19b23.vehicle',
      'namespace' => 'effectshop',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'be3ad9b731b8a5913f35f9b9b3331321',
      'native_key' => 'be3ad9b731b8a5913f35f9b9b3331321',
      'filename' => 'xPDOScriptVehicle/c25e146defb54ffabc496c677a852ccb.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);