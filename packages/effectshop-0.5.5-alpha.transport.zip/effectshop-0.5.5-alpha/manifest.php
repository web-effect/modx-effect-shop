<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.5.5-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '282e06b24a75beea8a1207d0465258fa',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/eb4318d509833a2c1670a63da7c236c3.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'b003b15cf41f81d4ad4757094b5c3f99',
      'native_key' => 'b003b15cf41f81d4ad4757094b5c3f99',
      'filename' => 'xPDOScriptVehicle/c34294d5b98401fc6a422a1e997bdab7.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b46b999b149efbd10ea9cf6654ad07a5',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/d638207be6492e7397f46438fafd63be.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3ddc3f63c70be1f973dbc5f6211903a6',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/5da52127670b3e4e5415c5a3ec01b3c6.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1c66456fb7a81afc86ef41aa69019c5a',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/053c50b366d9bbb9cb209fdd5f36cf14.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7cd9b610fcbe92824f815342fffedfa4',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/f388c4be4163182e1a15376fe8e6be98.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2479e2f277d0ce22adc186a1a3a342e7',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/ad4c24d22448354a1edf4e5d00e7d1fe.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '04d22434342dc227c726c9d5b9c46f84',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/137785f2a391e1fa698dbf3b2f159f2b.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd9178c5dfb050987ced81301b1602118',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/497de21d06cbdcde6d69b5d0e8e6bd84.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c72d0856807b1a83d5642dd36df2c9b0',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/1b5c0dc09f929a839f0f76ddd7c0c598.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77b57c3e4f8eebae6227dc2a70c8b217',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/040637fafd95d9a8ec82ca81a688b303.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3f8e555605834b690bc0d49150778c25',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/a73029e63c79bdcf58fca3a0647f33fe.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3423f22f30b34a6e7671d43600bf58f1',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/937c1c9a21a702c93cfa645a087d9ec1.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a997a4ee279c9991a4a66ff2a32a96b',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/43ffe932d28e3705fc7a8c6b5fe25682.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2722f61f9609093fe691590c5837a4a9',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/5a2b0ccab212e00ea18de2dcd678da02.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eca6cc71cc295d858700769a6171c7b2',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/99338f654fe502c3b712d9aeb2f78836.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '5f10420430757598cade975004b6ba62',
      'native_key' => 0,
      'filename' => 'shop_config/c529cfa5331f40773e2e54a33c132f5a.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'f4685fc7c8804c542c1bbd474642f057',
      'native_key' => 0,
      'filename' => 'shop_config/859cc0b8b9ea6cd3ba05c086c4fadc3b.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '5ec6f45119bc20d49ab95a9a7d1ea658',
      'native_key' => 0,
      'filename' => 'shop_config/db159de15fb64b35439f4967c77803ae.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '4d27ce44c2869f5c3e3a2b756f455926',
      'native_key' => 0,
      'filename' => 'modCategory/2f97f41f47a3f6fd65d8dd169825b772.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '54350ca5a100076e3fe3cd69e0cb546c',
      'native_key' => '54350ca5a100076e3fe3cd69e0cb546c',
      'filename' => 'xPDOScriptVehicle/3ef77afc36ceb92701caa333d4a5612c.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);