<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.3.19-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1ee24775e0a99f316bcf027e22f97544',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/0783885c79c8c6921ab63ef37b3e886d.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '42daca09a867b547f5af30833d9d81d5',
      'native_key' => '42daca09a867b547f5af30833d9d81d5',
      'filename' => 'xPDOScriptVehicle/8b82b540fabcadfe257459ef8a7eeefc.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '6b48d47623003bfb041cc4b24661c605',
      'native_key' => 'Заказы (Shop)',
      'filename' => 'modMenu/fcb9ef02fbcf74624e7d1c0c6b8240cd.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a37ea0461a8a00e790f974f04e5c8201',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/1207b6a04629d4bc39f56cc3048e6e70.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c9faa6c2040728392a748b3dedabec18',
      'native_key' => 'effectshop.shk',
      'filename' => 'modSystemSetting/23dc0679fc0e0cf195ffc440de6dd556.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2d0a671c514c486befe437b2aab8750b',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/6b212376f484916ff8b5ae7e986b83d2.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '37539fc58b721f2d35f2dc6b4ede4573',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/7d9b6dd64440c3de1a29a5f00d0f3f35.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3aa4f1f14db6362d072e86bcf92373d7',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/164292148f1e6851cc8891f97f3f0f1b.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5a119f54fcb097f89f14b76c8c1d81d',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/8a6142e4091f0b43a673370477d08512.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7156d5dcd9097347a7f22eea892d08d8',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/fcb426704bb92148995163ebb6ed30df.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '721f04fcd228d042eca264a81c3a7824',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/bf44c913c8cec417d7d264d54f4d5686.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b9f14d9dd24237cb6243f1493fe46741',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/ebfe54d277fcce6c08c32fac2335be11.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '530f66cf4856d3426f1b838dd6ac2b2b',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/d3f4b771a11de920cb5089ac2989476e.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bb699ca8db7179abea154203af293064',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/4f3c138733206e51eb0ebf126230fd5b.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '4c767ee6923ae3bf25d4ca2fca37fdb8',
      'native_key' => 0,
      'filename' => 'shop_config/b39d5765983c4603f02eec1deed1c456.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '4b9b6c3d7410aaea80b3fd5aed0dfded',
      'native_key' => 0,
      'filename' => 'shop_config/6ad0d4f052476775b9dfbbe410f1f50e.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'e5f9e5a00886e21cb2ff91c9ebe55b2c',
      'native_key' => 0,
      'filename' => 'shop_config/d43d9001b1d999d041e01a2cde0a11a2.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0342476772cdcf8c6a924e0047c93494',
      'native_key' => 0,
      'filename' => 'modCategory/900df12fb0c565b2cbb348b40d836c9e.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'daffc170d9c5659b78d2401af2035158',
      'native_key' => 'daffc170d9c5659b78d2401af2035158',
      'filename' => 'xPDOScriptVehicle/739e1e500dd3d6bd52d84c7a5fce22b3.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);