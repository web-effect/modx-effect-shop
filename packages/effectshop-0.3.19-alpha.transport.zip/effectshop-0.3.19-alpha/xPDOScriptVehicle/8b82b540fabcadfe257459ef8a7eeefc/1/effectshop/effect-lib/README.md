# Effect Framework

* Библиотеки:
    - vue.js
    - nouislider
* vue-компоненты
    - input
    - radio
    - checkbox
    - pagunation'
    - ranger
* Полифиллы
    - babel/polyfill
    - whatwg-fetch
    - ie11-custom-properties
    - closest(), NodeList.forEach(), CustomEvent