<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.5.4-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '06314f9ffd7e2c999ffabe105079ef74',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/7cd52251dbc2445e76f0f89c591ee2d5.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'ceb025116640901ec6bb4f7e17add64d',
      'native_key' => 'ceb025116640901ec6bb4f7e17add64d',
      'filename' => 'xPDOScriptVehicle/ba76a97bbaf4473190edcfe9247ca0b3.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9cba903ec8818949a903db1c041a90bc',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/bedb6b761737f5d79ee5ce7856eccdd9.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3da5418be52ca448e7dead7b530231e0',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/515b5b14c3cb4369491aa28249544934.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8f96ae21ef3b83227bdee73b44916ea3',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/9dae42dcad4218eeb907302caed89c43.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '170257053c45d1b40249e0e9ad14ecf3',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/0ff6ea6ec82e0132d0e6d709ba86f69f.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e79e3d5d911356b1022795fe05e9bd08',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/008481b461f5120043e443d1542fc5e8.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7844a39496f3e8124ae7342cda8eaa3f',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/2876784d5822fa2943b4b87d662aaafa.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7d07a3570c0d7346ecb013a25bd4a27',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/740d962cc3113c2eb89b007b8b8dbf37.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '843f47c71e7ccbaa4256654769e5c38e',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/8ddb4a5f1fc2e19fce3ba23d84ed56e3.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6261477b9464132ed6f5c217ff6b8954',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/508dc6262a5237964328c7ea8556b421.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a185b31d6092bb07893f62c98efd64d9',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/ca5ba7fcacede75c886b4ad66ad26371.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '56bc50f652eb979850e5e0db27e13abf',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/deef6c65d630b87895aed2c6b36c336d.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '463f945fc2be3e533dd35da5f597ee6e',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/e6de0309474356eeb903dd01991d69f0.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f649598435b10e2bcca0ec25060dbf62',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/294c3d743fc8dc02ae7188595be0196a.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '830dbca95da5c39622ac38433fe8447a',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/999df04d4eeff64335ac678818ca9f58.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '24b473f39fbf36a1bfbca8af76e35a8c',
      'native_key' => 0,
      'filename' => 'shop_config/a3dba794b53657d04e3eae66080b8928.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '066c806309cea01a85049d900157ebac',
      'native_key' => 0,
      'filename' => 'shop_config/5a58afb5ddc235539c626e6e9b39532c.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '8b36f6273d3c7c2f16d01813adde60d6',
      'native_key' => 0,
      'filename' => 'shop_config/e38811512530bb9207509cc0cf8469cd.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '68f14bddf1d955312bb3eeb828962a0d',
      'native_key' => 0,
      'filename' => 'modCategory/547175f27fa6c4801571f19c5283da57.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '8e5c20b4828952bb3bbc2633d50f7161',
      'native_key' => '8e5c20b4828952bb3bbc2633d50f7161',
      'filename' => 'xPDOScriptVehicle/bfbc0ae26aaa94de8b1723c9c74b14cf.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);