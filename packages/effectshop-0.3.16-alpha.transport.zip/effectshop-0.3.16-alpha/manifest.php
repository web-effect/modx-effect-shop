<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.3.16-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '87cd26a6866d86691b501d1e85ef1f5e',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/8d1653bfea376733ab1ce47f691593ae.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '156f6baaab32af2c41538d336dce1530',
      'native_key' => '156f6baaab32af2c41538d336dce1530',
      'filename' => 'xPDOScriptVehicle/94b39ac0da7a5ee1f351b0673b41096e.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '2202553a575a9aa06460bf108e4ca3a0',
      'native_key' => 'Shop',
      'filename' => 'modMenu/75eef69de0c76527cc0aaac1ff9e7bbf.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21a6e92c9e0142614d3aaac126a05b07',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/116ecf3bfeefab10827c30928dde1d08.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '402d0cd4e660898ed7ffa9e767db7fc0',
      'native_key' => 'effectshop.shk',
      'filename' => 'modSystemSetting/fac29231fc592b55590ac710fdb3d6c3.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '17af217fdba2655ebc2a2b51ca334bcd',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/efa2b32d7531f2e400182b57de2352d8.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cbb5ca9cfa2b9a9fd9ff8086e051cd57',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/cb28a734cdfe0e6b22c960bffe891721.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '52ed139ff58df1d22c7c29d768356bec',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/28222b5052c7323d3402db4e5299128c.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd630da3d5790f70b84260206198091d7',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/7875f3fd013cb2f67a41591049698b79.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2c6784f0298195c248a9e027e5f5039',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/35f140e1b587352303dfa95a265b092f.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb49005ec770113bbdda0f5042013199',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/be4848e58d5dd5a68b65858152d4344b.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'eb63f103eb23970a1ff5d52c8f941eda',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/8ec0db8ea770872c15ff0666636c6091.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '681230c325a0167a5d7ecc2e2205e01c',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/6c351507ce88f00ffcfd0daf97978d8b.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '1396b36b2f04d1dd0ed2f150d18a1377',
      'native_key' => 0,
      'filename' => 'shop_config/3897747906133a4a06cd9164b8966174.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '73b54da36b47189882149763da5d8012',
      'native_key' => 0,
      'filename' => 'shop_config/404ac2c3448f54a18b4efb8b50afe86a.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'dfa016bf4fa11ffcd398ce3a1ff24fc1',
      'native_key' => 0,
      'filename' => 'shop_config/9985177c45a64c7753b329deae2e39d7.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '435169e52f6acd39c7040801e4731595',
      'native_key' => 0,
      'filename' => 'modCategory/fa047c02203ed81e94a3a9308e3d881e.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'c8ce005c06ae8ef6bacbdfb4cb24bd58',
      'native_key' => 'c8ce005c06ae8ef6bacbdfb4cb24bd58',
      'filename' => 'xPDOScriptVehicle/c9876503522f97542f98577a5fe9af24.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);