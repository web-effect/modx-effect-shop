<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.5.1-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '13acf57195a5159feb82929f7eecc79b',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/2e3e536733204092d877144b275b66ba.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'ce6bb0e5a946e38127fe5b6b2a590c05',
      'native_key' => 'ce6bb0e5a946e38127fe5b6b2a590c05',
      'filename' => 'xPDOScriptVehicle/bf022c099ecb646cf9c12b27f7479a25.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'e8ba789b7e248d6b40432d3935d9787a',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/8d9981ba8d1f6f5612ce76607ad9f748.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '97d68bbe128adc16160a91844a8490f4',
      'native_key' => 0,
      'filename' => 'shop_config/bcec25304cb8380d986df329fefcc32c.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '8a5fb2a5b0b38815ade274746bc31d9f',
      'native_key' => 0,
      'filename' => 'shop_config/49f03627e0caae3a8c60a7495e3e4617.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '333301a923fdf87865e7b4ac3be2943e',
      'native_key' => 0,
      'filename' => 'shop_config/5bcb6daf58bf4fce5b6c3a232e507ed7.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'af9277732df58cef667204dc82ba394a',
      'native_key' => 0,
      'filename' => 'modCategory/d44175d3a7000c3814156a6dd28cb610.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3c275b3d17873d27b9633c626f87129b',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/2669e368cbdbc6b87926993bf1fdc677.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0093d16f8bf7274838e89c3ad7cb3c90',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/07ddd344e5abedb3a3818b5dd1113ae7.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b50f2e9628e1ee4f4d2cadf91def2edf',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/8df718d282b5ae5940234459014b89ae.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c7284dbad912b2e815d87c31a241eb65',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/16c8ed7736a7c3b90687447b93261fb8.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'abb0924d8c23bc92e9f1de91f4fb8d67',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/41806c72f15185a434b85fbc4ce7ff76.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fdc4bfa3d4fcaea4b63e22f53b521c2a',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/c3867e3d20c7a4362aa66da8451f80d1.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88466bd6a0c026969369b46817b2f240',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/c97c0cdd7e1a89130cb170cbf72dcca1.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd97b833a71fbc0f9d0e3721e4985f2dc',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/849731d7493cb20a2e86aa5971427c75.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b0bea45c5ab56ee6ca935a7859ba107e',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/414712892f35ca2f8e8b6314e362eb1b.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9a89d54eca1e4a702d49b0a6f2d8aec',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/277fb4978be20d3949c1d17dfc68227b.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '32065c5f6b2a600c862bde51f9872930',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/b0dc132686fb36a9cd0444caab557262.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7c669f1f91251c9d64978c90477cc734',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/cef47530a5aacd8546ed7ec1b50d9032.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '6cdc562415dd4f1fa4ce0232eb801fc8',
      'native_key' => '6cdc562415dd4f1fa4ce0232eb801fc8',
      'filename' => 'xPDOScriptVehicle/724c4ba08b4fcd9f7797b04b6cbc2536.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);