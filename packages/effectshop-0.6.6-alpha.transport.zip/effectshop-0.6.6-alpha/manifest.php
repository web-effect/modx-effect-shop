<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.6.6-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5e7cee8a939ab17f7c2a326c6d156c31',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/229ad5fc83443163daa45d81fb65c8c8.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '9d2c856a578e95c2e8b30df479f37360',
      'native_key' => '9d2c856a578e95c2e8b30df479f37360',
      'filename' => 'xPDOScriptVehicle/f734ba18ae93460f71253d976d99251b.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '320aee4f6d83095dd307157ca13e3d28',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/819596ba7b8bda2943d6e61590845fbb.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '768ce5c7bcd137b95785f17476783334',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/2edc2b92bab9b101a734b9fcddf74253.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fe97bf7b809a66308f6f2aaa0581d7d2',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/ab475270608179cfba403249c3ae3209.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd393862f41274eb1553389f1d60ffce7',
      'native_key' => 'ShopOrderBeforeSendEmails',
      'filename' => 'modEvent/007c8517212ed1a6fb908c1f635b26f7.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '45912441bb8b82871bc0a08dd6ce3908',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/43c4a2c21a86dbea5c85303efedbf06a.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'e980cccc3b4d67c1eb6014cf04c4083b',
      'native_key' => 0,
      'filename' => 'shop_config/0f463e4e1b05472efd6982ec12c62327.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => '1b0df33196b7af92cc9c87eb20d6bb8e',
      'native_key' => 0,
      'filename' => 'shop_config/a66dc5447c9a7a9bb92da098d2a1e86e.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'a2ae19a93ec652fcef032ad0193f5096',
      'native_key' => 0,
      'filename' => 'shop_config/93922f2475f6353ee4fa6cb1bc327815.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'fc96b0587b3cf6b88a818fb8e201e083',
      'native_key' => 0,
      'filename' => 'modCategory/cbdc00796826794ff2c6b86728ec42bd.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a275d9966c891a3feaba7e7b98ea1331',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/d9c63752c66857dae507a89bc34df28e.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '909199660653b281b28f560ebb4f2e98',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/6e000523e4afd28d867d9cd0afdcea3c.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'df68862eb90fbe483c1f1e4253ad8bd5',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/c7e9df77d498aec728a8cea92e832a0b.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cc918375e080264f480315a6e460cb79',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/2f7d2496846eaf105dfeba3ff0c96a11.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3e5d06767c99c557f843086e8fad72e',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/bb9722cb3285bbd13ae10a2b2bf92497.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4b57df141a798f85bd656b3b2bb9d307',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/324c30ef614660f847eef1dcf79edf59.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2581d7fe3937111c693913c0d02a632b',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/08d99f4e1d23364bcac5958ca57879db.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09506e019e77c64db834d9e8f95b7db7',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/e38583d3c93be6dc1b0b4a0c3449e031.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03ae493f995d230f98c1e51167305ebd',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/060ac4994ae13724e3e43efd4c07049f.vehicle',
      'namespace' => 'effectshop',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'dd3da2cf471b3eb4f94e402c2e9d6d4a',
      'native_key' => 'dd3da2cf471b3eb4f94e402c2e9d6d4a',
      'filename' => 'xPDOScriptVehicle/c42dd15ce9ea1b455da175680c4e27d0.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);