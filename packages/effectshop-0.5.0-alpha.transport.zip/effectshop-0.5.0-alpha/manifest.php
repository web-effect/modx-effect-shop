<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'requires' => 
    array (
      'php' => '>=7.2',
    ),
    'setup-options' => 'effectshop-0.5.0-alpha/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '21bb7fe22e4b26ff90fbc0ff993e4748',
      'native_key' => 'effectshop',
      'filename' => 'modNamespace/047c460e1967d3f5325c09a38667e3cc.vehicle',
      'namespace' => 'effectshop',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => 'dad6c642d28c9d185771b43b556bb415',
      'native_key' => 'dad6c642d28c9d185771b43b556bb415',
      'filename' => 'xPDOScriptVehicle/9fde1c72124d5b204514f0994b242905.vehicle',
      'namespace' => 'effectshop',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '35e786630c75470d8ce5672fb39a01ad',
      'native_key' => 'Магазин',
      'filename' => 'modMenu/a16d5534c3f51c9af5c63d3bfef31ad5.vehicle',
      'namespace' => 'effectshop',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'ad0a0583702dfa42bde9a078034f3381',
      'native_key' => 0,
      'filename' => 'shop_config/6cb7e0a4c480e97eeb646744d3d7b106.vehicle',
      'namespace' => 'effectshop',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'a96b23cf642e5c86b92054038dd3dcdb',
      'native_key' => 0,
      'filename' => 'shop_config/26161eeb9086323b595fd30bd0a093bb.vehicle',
      'namespace' => 'effectshop',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'shop_config',
      'guid' => 'cb3d77efc50b608bbd0b7b092a89a14a',
      'native_key' => 0,
      'filename' => 'shop_config/c0cdb103194a90df893a3b4bc4dae826.vehicle',
      'namespace' => 'effectshop',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0d38c4cd334ddde4ee212f947e56b7b0',
      'native_key' => 0,
      'filename' => 'modCategory/f79df57dd7ff2103a9586d968046b55d.vehicle',
      'namespace' => 'effectshop',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ebe39009b8d2accf115404a15b9eeff',
      'native_key' => 'mail_to',
      'filename' => 'modSystemSetting/1020bc327e9505de9dd27c2f4214bb33.vehicle',
      'namespace' => 'effectshop',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1adfe21f5f8a36f8462af03621b6dbcf',
      'native_key' => 'effectshop.product_tmpls',
      'filename' => 'modSystemSetting/7053661ba6f25c6da79b859e01815c29.vehicle',
      'namespace' => 'effectshop',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0283abc1b3f6515cdaa2df0b227c55ed',
      'native_key' => 'effectshop.section_tmpls',
      'filename' => 'modSystemSetting/ef1e09310e5f7b8f0650503a05b6737f.vehicle',
      'namespace' => 'effectshop',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '55ba6381b87783bb2812c1d0dbb0840d',
      'native_key' => 'effectshop.product_get_fields',
      'filename' => 'modSystemSetting/9f6f84e869aff263f91c17ba629363f6.vehicle',
      'namespace' => 'effectshop',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64eb3c8fb2486cc3f9fef9b09da328e6',
      'native_key' => 'effectshop.thumb',
      'filename' => 'modSystemSetting/bde0cd6dce4f365e4bff2f6f7c0fc749.vehicle',
      'namespace' => 'effectshop',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0cf7da20dc3cdc605c9d8dd7a0eb3255',
      'native_key' => 'effectshop.order_report_tpl',
      'filename' => 'modSystemSetting/49a388b10c137c30a08f1678771ab5f4.vehicle',
      'namespace' => 'effectshop',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aabd9a0c7800901f353dbc7e3f2b8124',
      'native_key' => 'effectshop.filter_exclude',
      'filename' => 'modSystemSetting/4ab3f0dd6d5da1adebc447b095d4f080.vehicle',
      'namespace' => 'effectshop',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '862df7813bc5a538362cb5c07b46afd3',
      'native_key' => 'effectshop.filter_collections',
      'filename' => 'modSystemSetting/0901a4bddf131239a0903a9c0967f975.vehicle',
      'namespace' => 'effectshop',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fce968f9d8faf0ddd1f28576ad6c716d',
      'native_key' => 'effectshop.contact_fields',
      'filename' => 'modSystemSetting/49fac6b962aaa143415ba6142dd2fb50.vehicle',
      'namespace' => 'effectshop',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '965bac0abcce7a166c527ee9227defbd',
      'native_key' => 'ShopCartBeforeProcess',
      'filename' => 'modEvent/3b8444eff4157a3ef109fbf4befa18f7.vehicle',
      'namespace' => 'effectshop',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '31f2024eb8d86974397c266dd42848d1',
      'native_key' => 'ShopCartAfterProcess',
      'filename' => 'modEvent/576c6c31a1410399c6c50a86f1bfbd10.vehicle',
      'namespace' => 'effectshop',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5d976b7e20d6ecb9b33f3ea6096d687e',
      'native_key' => 'ShopOrderStatusChange',
      'filename' => 'modEvent/c0fa6ee555f415c80c920cb99046d1dc.vehicle',
      'namespace' => 'effectshop',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOScriptVehicle',
      'class' => 'xPDOScriptVehicle',
      'guid' => '72959c8f2d9b528e8db1baeed9cd28d1',
      'native_key' => '72959c8f2d9b528e8db1baeed9cd28d1',
      'filename' => 'xPDOScriptVehicle/766957304766c1dff0046febec015ebf.vehicle',
      'namespace' => 'effectshop',
    ),
  ),
);